export default function configureStore() {
  return {
    getState: () => ({}),
    dispatch: () => {},
    subscribe: () => () => {},
  }
}


