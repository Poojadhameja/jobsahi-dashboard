export default function rootReducer(state = {}, action) {
  switch (action.type) {
    default:
      return state
  }
}


