export const env = {
    // apiHost: "http://localhost/JOBSAHI-API/api",   //local
    apiHost: "https://beige-jaguar-560051.hostingersite.com/api",
    frontUrl: "http://localhost:5173",
};
