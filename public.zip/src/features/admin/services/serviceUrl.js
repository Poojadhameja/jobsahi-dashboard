const service = {
    //admin url
    studentsList: '/admin/list_students.php',
    employersList: '/admin/list_employers.php',
    institutesList: '/admin/list_institutes.php',

    updateEmployer: '/employer/update_recruiter_profile.php',
    updateInstitute: '/institute/profile_updated.php'

}

export default service;